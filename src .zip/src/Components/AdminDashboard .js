import React, { useEffect, useState } from "react";
import axios from "axios";

const AdminPage = () => {
  const [doctors, setDoctors] = useState([]);
  const [patients, setPatients] = useState([]);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        // Fetch doctors
        const doctorResponse = await axios.get(
          "https://localhost:7072/api/User/GetUsersByRole/2",
          {
            headers: {
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          }
        );
        setDoctors(doctorResponse.data);

        // Fetch patients
        const patientResponse = await axios.get(
          "https://localhost:7072/api/User/GetUsersByRole/3",
          {
            headers: {
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          }
        );
        setPatients(patientResponse.data);
      } catch (error) {
        console.error("Error fetching data", error);
      }
    };

    fetchUsers();
  }, []);

  return (
    <div>
      <h2>Admin Dashboard</h2>

      <h3>Doctors</h3>
      <ul>
        {doctors.map((doctor) => (
          <li key={doctor.userId}>
            {doctor.firstName} {doctor.lastName} ({doctor.emailID})
          </li>
        ))}
      </ul>

      <h3>Patients</h3>
      <ul>
        {patients.map((patient) => (
          <li key={patient.userId}>
            {patient.firstName} {patient.lastName} ({patient.emailID})
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AdminPage;
