import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [loginAs, setLoginAs] = useState("user"); // State for login role selection
  const [signupAs, setSignupAs] = useState("doctor"); // State for signup role selection
  const [selectedValue, setSelectedValue] = useState("");

  // Login

  const [emailId, setEmailId] = useState("");
  const [loginpassword, setPassword] = useState("");
  const [accessToken, setAccessToken] = useState("");

  const [user, setUser] = useState({
    firstName: "",
    lastName: "",
    password: "",
    phoneNumber: "",
    emailID: "",
    roleID: 0,
    statusID: 1,
  });

  const {
    firstName,
    lastName,
    password,
    phoneNumber,
    emailID,
    roleID,
    statusID,
  } = user;

  const navigate = useNavigate();

  const onInputChange = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    console.log(name + " " + event.target.value);

    setUser((anyPara) => {
      return { ...anyPara, [name]: value };
    });
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    debugger;
    user.roleID = selectedValue;

    await axios.post("https://localhost:7072/api/Authenticate/register", user);
    alert("Registered Successfully");
    //navigate("/");
  };

  const handleDropdownChange = (event) => {
    debugger;
    setSelectedValue(event.target.value); // Update the state with the selected value
  };

  // login

  const handleLogin = async (e) => {
    e.preventDefault();
    debugger;
    try {
      let roleID = parseInt(selectedValue);
      let password = loginpassword;
      const response = await axios.post(
        "https://localhost:7072/api/Authenticate/PostLoginDetails",
        { emailId, password, roleID }
      );
      console.log(response.data);
      setAccessToken(response.data.accessToken);
      localStorage.setItem("token", response.data.accessToken); // store token locally
      localStorage.setItem("userId", response.data.userId);
      //navigate("/dashboard");
      alert("Login Successfully");
      if (response.data.roleID == 1) {
        navigate("/admin/admindashboard");
      } 
      if (response.data.roleID == 2) {
        navigate("/doctor/doctordashboard");
      } 
      else {
        alert("Site is under maintenance");
      }
    } catch (error) {
      console.log("Login Failed", error);
      alert("Login Failed");
    }
  };

  return (
    <div className="container">
      <div className="form-container">
        <div className="form-toggle">
          <button
            className={isLogin ? "active" : ""}
            onClick={() => setIsLogin(true)}
          >
            Login
          </button>
          <button
            className={!isLogin ? "active" : ""}
            onClick={() => setIsLogin(false)}
          >
            SignUp
          </button>
        </div>

        {isLogin ? (
          <>
            <div className="form">
              <h2>Login Form</h2>
              <label htmlFor="loginAs">Login as:</label>
              <select value={selectedValue} onChange={handleDropdownChange}>
                <option value="" selected="">
                  select role
                </option>

                <option value="1">Admin</option>
                <option value="2">Doctor</option>
                <option value="3">Patient</option>
              </select>

              <form onSubmit={handleLogin}>
                <div className="form-group">
                  <input
                    type="text"
                    className="form-control form-control-lg"
                    placeholder="Enter your Email"
                    name="email"
                    value={emailId}
                    onChange={(e) => setEmailId(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <input
                    type="password"
                    className="form-control form-control-lg"
                    placeholder="Enter your password"
                    name="loginpassword"
                    value={loginpassword}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>

                <button type="submit" className="btn btn-danger btn-block">
                  Login
                </button>
              </form>

              {/* <input type="email" placeholder="Email" />
              <input type="password" placeholder="Password" /> */}
              <a href="#">Forgot Password?</a>
              <button>Login</button>
              <p>
                Not a Member?{" "}
                <a href="#" onClick={() => setIsLogin(false)}>
                  Signup now
                </a>
              </p>
            </div>
          </>
        ) : (
          <>
            <label htmlFor="signupAs">Signup as:</label>
            <div className="form">
              <select value={selectedValue} onChange={handleDropdownChange}>
              <option value="" selected="">
                  select role
                </option>
                <option value="2">Doctor</option>
                <option value="3">Patient</option>
              </select>
              <form onSubmit={handleSignup}>
                <div className="form-group">
                  <input
                    type="text"
                    className="form-control form-control-lg"
                    placeholder="Enter your firstName"
                    name="firstName"
                    value={firstName}
                    onChange={onInputChange}
                    required
                  />
                </div>

                <div className="form-group">
                  <input
                    type="text"
                    className="form-control form-control-lg"
                    placeholder="Enter your lastName"
                    name="lastName"
                    value={lastName}
                    onChange={onInputChange}
                    required
                  />
                </div>

                <div className="form-group">
                  <input
                    type="password"
                    className="form-control form-control-lg"
                    placeholder="Enter your password"
                    name="password"
                    value={password}
                    onChange={onInputChange}
                    required
                  />
                </div>

                <div className="form-group">
                  <input
                    type="text"
                    className="form-control form-control-lg"
                    placeholder="Enter your phoneNumber"
                    name="phoneNumber"
                    value={phoneNumber}
                    onChange={onInputChange}
                    required
                  />
                </div>

                <div className="form-group">
                  <input
                    type="email"
                    className="form-control form-control-lg"
                    placeholder="Enter your emailID"
                    name="emailID"
                    value={emailID}
                    onChange={onInputChange}
                    required
                  />
                </div>

                <button type="submit" className="btn btn-danger btn-block">
                  Register
                </button>
              </form>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Login;
