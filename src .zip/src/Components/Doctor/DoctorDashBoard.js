import React from "react";
import { NavLink, Link } from "react-router-dom";
const DoctorDashBoard = () => {
  return (
    <>
      <div className="container mt-1 pt-5">
        <div className="mt-4 p-5 bg-primary text-white rounded">
          <h2>DashBoard</h2>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim
            ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
            aliquip ex ea commodo consequat..
          </p>

          <NavLink
            className="btn btn-sm btn-primary"
            exact
            to={"/doctor/adddoctordetails"}
          >
            Add or Update Details
          </NavLink>
        </div>
      </div>
    </>
  );
};

export default DoctorDashBoard;
