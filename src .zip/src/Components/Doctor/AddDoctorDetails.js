import React, { useState,useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const AddDoctorDetails = () => {
  const [doctor, setDoctor] = useState({
    doctorId: 0,
    userId: 0,
    specializationId: "",
    profileImage: "",
    city: "",
    rating:0
  });

  const [specialization, setSpecialization] = useState([]);
  useEffect(() => {
    loadSpecialization();
  }, []);
  const loadSpecialization = async () => {
    const token = localStorage.getItem("token"); // Get token from localStorage
    try {
      const response = await axios.get(
        "https://localhost:7072/api/Specializations",
        {
          headers: {
            Authorization: `Bearer ${token}`, // Set JWT token in headers
          },
        }
      );
 
      setSpecialization(response.data); //assigning value to collection after reading from api

      console.log("Secure data:", response.data);
    } catch (error) {
      console.error("Failed to fetch secure data", error);
    }
  };


  const [selectedValue, setSelectedValue] = useState("");

  const navigate = useNavigate();
  const { doctorId, userId, specializationId, profileImage, city } = doctor;

  const onInputChange = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    console.log(name + " " + event.target.value);

    setDoctor((anyPara) => {
      return { ...anyPara, [name]: value };
    });
  };

  const handleDropdownChange = (event) => {
    debugger;
    setSelectedValue(event.target.value); // Update the state with the selected value
  };

  const handleDetails = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("token");
    const userId = localStorage.getItem("userId");
    debugger;
    doctor.specializationId = selectedValue;
    doctor.userId = userId;

    await axios.post("https://localhost:7072/api/DoctorDetails", doctor, {
      headers: {
        Authorization: `Bearer ${token}`, // Set JWT token in headers
      }
    });

    alert("Registered Successfully");
    navigate("/doctor/doctordashboard");
  };





  return (
    <div class="login">
      <div className="container-fluid bg-secondary rounded-2">
        <div className="w-100 mx-auto shadow">
          <h2 className="text-center mb-4">Add Details</h2>

          <label className="w-100 bg-secondary">Select your specialization:</label>

          <select className="w-100 form-control" value={selectedValue} onChange={handleDropdownChange}>
            <option value="">--Choose a specialization--</option>
            {specialization.map((specialization) => (
              <option key={specialization.specializationId} value={specialization.specializationId}>
                {specialization.specializationName}
              </option>
            ))}
          </select>

          <form onSubmit={handleDetails}>
            <div className="form-group">
              <input
                type="text"
                className="form-control form-control-lg"
                placeholder="Enter your profileImage"
                name="profileImage"
                value={profileImage}
                onChange={onInputChange}
                required
              />
            </div>

            <div className="form-group">
              <input
                type="text"
                className="form-control form-control-lg"
                placeholder="Enter your city"
                name="city"
                value={city}
                onChange={onInputChange}
                required
              />
            </div>

            <button type="submit" className="btn btn-danger btn-block">
              Register
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AddDoctorDetails;
