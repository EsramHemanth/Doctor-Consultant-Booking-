import React, { useEffect, useState } from "react";
import axios from "axios";
import { NavLink, Link } from "react-router-dom";

const AdminUsers = () => {
  const [users, setUsers] = useState([]);
  useEffect(() => {
    loadUsers();
  }, []);
  const loadUsers = async () => {
    const token = localStorage.getItem("token"); // Get token from localStorage
    try {
      const response = await axios.get(
        "https://localhost:7072/api/Users",
        {
          headers: {
            Authorization: `Bearer ${token}`, // Set JWT token in headers
          },
        }
      );
      // .then(response => {
      //   setUsers(response.data);  // Update state with fetched data
      // })
      setUsers(response.data); //assigning value to collection after reading from api

      console.log("Secure data:", response.data);
    } catch (error) {
      console.error("Failed to fetch secure data", error);
    }
  };

  const deleteUser = async (id) => {
    const token = localStorage.getItem("token"); // Get token from localStorage
    try {
      const response = await axios.delete(
        `https://localhost:7072/api/Users/${id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`, // Set JWT token in headers
          },
        }
      );
      loadUsers();
    } catch (error) {
      console.error("Failed to fetch secure data", error);
    }
  };
  return (
    <div className="container">
      <div className="py-4">
        <h1>
          Users Panel{" "}
          <span>
            <NavLink
              className="btn btn-sm btn-primary"
              exact
              to={"/admin/adduser"}
            >
              Add New
            </NavLink>
          </span>
        </h1>
        <table class="table border shadow">
          <thead class="table-dark">

   
  {/* "roleID": 0,
  "statusID": 0 */}

            <tr>
              <th scope="col">#</th>
              <th scope="col">UserId</th>
              <th scope="col">First Name</th>
              <th scope="col">Last Name</th>
              <th scope="col">Phone Number</th>
              <th scope="col">EmailID</th>
              <th scope="col">Role</th>
              <th scope="col">Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {users.map((user, index) => (
              <tr>
                <th scope="row">{index + 1}</th>
                <td>{user.userId}</td>
                <td>{user.firstName}</td>
                <td>{user.lastName}</td>
                <td>{user.phoneNumber}</td>
                <td>{user.emailID}</td>
                <td>{ user.roleID == 1 ? "Admin" : user.roleID == 2 ? "Doctor" : "Patient"  }</td>
                <td>{ user.statusID  == 1 ? "Pending" : user.statusID == 2 ? "Accepted" : "Rejected"  }</td>
                <td>
                  <NavLink
                    className="btn btn-sm btn-primary"
                    exact
                    to={`/admin/userdetails/${user.userId}`}
                  >
                    View
                  </NavLink>
                  <NavLink
                    className="btn btn-sm btn-warning"
                    exact
                    to={`/admin/edituser/${user.userId}`}
                  >
                    Edit
                  </NavLink>
                  <NavLink
                    className="btn btn-sm btn-danger"
                    onClick={() => deleteUser(user.userId)}
                  >
                    Delete
                  </NavLink>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default AdminUsers