import React from "react";
import { useState, useEffect } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import { NavLink } from "react-router-dom";
const UserDetails = () => {
  const [user, setUser] = useState({
    userId: "",
    firstName: "",
    lastName: "",
    password: "",
    phoneNumber: "",
    emailID: "",
    roleID: 0,
    statusID: 0,
  });

  const { id } = useParams();
  useEffect(() => {
    UserData();
  }, []);
  const UserData = async () => {
    const token = localStorage.getItem("token"); // Get token from localStorage
    try {
      const response = await axios.get(
        `https://localhost:7072/api/Users/${id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`, // Set JWT token in headers
          },
        }
      );

      setUser(response.data); //assigning value to collection after reading from api

      console.log("Secure data:", response.data);
    } catch (error) {
      console.error("Failed to fetch secure data", error);
    }
  };

  return (
    <div className="w-100 mx-auto shadow p-5">
      <div className="card-body">
        <h5 className="card-title">User Details</h5>

        <ul className="list-group list-group-flush">
          <li className="list-group-item">{user.userId}</li>
          <li className="list-group-item">{user.firstName}</li>
          <li className="list-group-item">{user.lastName}</li>
          <li className="list-group-item">{user.phoneNumber}</li>
          <li className="list-group-item">{user.emailID}</li>

          <li className="list-group-item">
            {user.roleID == 1
              ? "Admin"
              : user.roleID == 2
              ? "Doctor"
              : "Patient"}
          </li>
          <li className="list-group-item">
            {user.statusID == 1
              ? "Pending"
              : user.statusID == 2
              ? "Accepted"
              : "Rejected"}
          </li>
        </ul>
        <div className="card-body">
          <NavLink className="card-lin" to={`/admin/adminusers`}>
            Back to Panel
          </NavLink>
        </div>
      </div>
    </div>
  );
};

export default UserDetails;
