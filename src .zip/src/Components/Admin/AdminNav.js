import React from "react";
import { Link, NavLink } from "react-router-dom";
import { useNavigate } from "react-router-dom";

const AdminNav = () => {
  const navigate = useNavigate();

  const LogOut = () => {
   localStorage.removeItem("token");
   navigate("/");
 
 };

  return (
    <>
      <nav className="navbar fixed-top navbar-expand-sm navbar-dark bg-dark ">
        <div className="container-fluid">
          <NavLink className="navbar-brand" to="/dashboard">
            Admin Section
          </NavLink>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#mynavbar"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="mynavbar">
            <ul className="navbar-nav me-auto">
              <li className="nav-item">
                <NavLink
                  className="nav-link"
                  href="javascript:void(0)"
                  to="/admin/admindashboard"
                >
                 DashBoard
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  className="nav-link"
                  href="javascript:void(0)"
                  to="/admin/adminusers"
                >
                  Manage Users
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  className="nav-link"
                  href="javascript:void(0)"
                  // to="/contactus"
                >
                  Contact Us
                </NavLink>
              </li>
              <li className="nav-item">
                {/* <NavLink className="nav-link" href="javascript:void(0)" to="/contactus">
                 
                </NavLink> */}
                <button
                  className="btn btn-sm btn-danger nav-link"
                  onClick={LogOut}
                >
                  Sign Out
                </button>
              </li>
            </ul>
            <form className="d-flex">
              <input
                className="form-control me-2"
                type="text"
                placeholder="Search"
              />
              <button className="btn btn-primary" type="button">
                Search
              </button>
            </form>
          </div>
        </div>
      </nav>
    </>
  );
};

export default AdminNav;
