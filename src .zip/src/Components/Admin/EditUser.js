import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { useParams } from "react-router-dom";

const EditUser = () => {
  const [user, setUser] = useState({
    firstName: "",
    lastName: "",
    password: "",
    phoneNumber: "",
    emailID: "",
    roleID: 0,
    statusID: 0,
  });

  const {
    
    firstName,
    lastName,
    password,
    phoneNumber,
    emailID,
    roleID,
    statusID,
  } = user;
  const [selectedValuestatus, setSelectedValuestatus] = useState("");
  const [selectedValuerole, setSelectedValuerole] = useState("");

  const navigate = useNavigate();

  const onInputChange = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    console.log(name + " " + event.target.value);

    setUser((anyPara) => {
      return { ...anyPara, [name]: value };
    });
  };
  const { id } = useParams();
  useEffect(() => {
    userData();
  }, []);

  const userData = async () => {
    const token = localStorage.getItem("token"); // Get token from localStorage
    try {
      const response = await axios.get(
        `https://localhost:7072/api/Users/${id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`, // Set JWT token in headers
          },
        }
      );

      setUser(response.data); //assigning value to collection after reading from api
      setSelectedValuerole(response.data.roleID);
      setSelectedValuestatus(response.data.statusID);

      console.log("Secure data:", response.data);
    } catch (error) {
      console.error("Failed to fetch secure data", error);
    }
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("token");

    user.roleID = selectedValuerole;
    user.statusID = selectedValuestatus;

    await axios.put(`https://localhost:7072/api/Users/${id}`, user, {
      headers: {
        Authorization: `Bearer ${token}`, // Set JWT token in headers
      },
    });
    navigate("/admin/adminusers");
  };
  const handleDropdownChangeStatus = (event) => {
    debugger;
    setSelectedValuestatus(event.target.value); // Update the state with the selected value
  };

  const handleDropdownChangerole = (event) => {
    debugger;
    setSelectedValuerole(event.target.value); // Update the state with the selected value
  };

  return (
    <div class="login">
      <div className="container-fluid bg-secondary rounded-2">
        <div className="w-100 mx-auto shadow">
          <h2 className="text-center mb-4">Edit user details</h2>
          <select
            className="w-100 form-control"
            value={selectedValuerole}
            onChange={handleDropdownChangerole}
          >
            <option value="" selected="">
              select role
            </option>
            <option value="1">Admin</option>
            <option value="2">Doctor</option>
            <option value="3">Patient</option>
          </select>
          <select
            className="w-100 form-control"
            value={selectedValuestatus}
            onChange={handleDropdownChangeStatus}
          >
            <option value="" selected="">
              select role
            </option>
            <option value="1">Pending</option>
            <option value="2">Accepted</option>
            <option value="4">Rejected</option>
          </select>
          <form onSubmit={handleUpdate}>
            <div className="form-group">
              <input
                type="text"
                className="form-control form-control-lg"
                placeholder="Enter your firstName"
                name="firstName"
                value={firstName}
                onChange={onInputChange}
                required
              />
            </div>

            <div className="form-group">
              <input
                type="text"
                className="form-control form-control-lg"
                placeholder="Enter your lastName"
                name="lastName"
                value={lastName}
                onChange={onInputChange}
                required
              />
            </div>

            <div className="form-group">
              <input
                type="password"
                className="form-control form-control-lg"
                placeholder="Enter your password"
                name="password"
                value={password}
                onChange={onInputChange}
                required
              />
            </div>

            <div className="form-group">
              <input
                type="text"
                className="form-control form-control-lg"
                placeholder="Enter your phoneNumber"
                name="phoneNumber"
                value={phoneNumber}
                onChange={onInputChange}
                required
              />
            </div>

            <div className="form-group">
              <input
                type="email"
                className="form-control form-control-lg"
                placeholder="Enter your emailID"
                name="emailID"
                value={emailID}
                onChange={onInputChange}
                required
              />
            </div>

            <button type="submit" className="btn btn-danger btn-block">
              Update
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default EditUser;
