import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const AddUser = () => {
  const [user, setUser] = useState({
    firstName: "",
    lastName: "",
    password: "",
    phoneNumber: "",
    emailID: "",
    roleID: 0,
    statusID: 1
  });

  const [selectedValue, setSelectedValue] = useState("");

  const navigate = useNavigate();
  const {
    firstName,
    lastName,
    password,
    phoneNumber,
    emailID,
    roleID,
    statusID,
  } = user;
  const onInputChange = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    console.log(name + " " + event.target.value);

    setUser((anyPara) => {
      return { ...anyPara, [name]: value };
    });
  };

  const Login = () => {
    localStorage.removeItem("token");
    navigate("/");
  };
  const handleDropdownChange = (event) => {
    debugger;
    setSelectedValue(event.target.value); // Update the state with the selected value
  };


  const handleSignup = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("token"); 
    debugger;
    user.roleID = selectedValue;
    await axios.post("https://localhost:7072/api/Users", user,
      {
        headers: {
          Authorization: `Bearer ${token}`, // Set JWT token in headers
        },
      })

    alert("Registered Successfully");
    navigate("/admin/adminusers");
  };

  return (
    <div class="login">
      <div className="container-fluid bg-secondary rounded-2">
        <div className="w-100 mx-auto shadow">
          <h2 className="text-center mb-4">Register New User</h2>
          <select className="w-100 form-control" value={selectedValue} onChange={handleDropdownChange}>
                <option value="" selected="">
                  select role
                </option>
                <option value="1">Admin</option>
                <option value="2">Doctor</option>
                <option value="3">Patient</option>
              </select>
          <form onSubmit={handleSignup}>
                <div className="form-group">
                  <input
                    type="text"
                    className="form-control form-control-lg"
                    placeholder="Enter your firstName"
                    name="firstName"
                    value={firstName}
                    onChange={onInputChange}
                    required
                  />
                </div>

                <div className="form-group">
                  <input
                    type="text"
                    className="form-control form-control-lg"
                    placeholder="Enter your lastName"
                    name="lastName"
                    value={lastName}
                    onChange={onInputChange}
                    required
                  />
                </div>

                <div className="form-group">
                  <input
                    type="password"
                    className="form-control form-control-lg"
                    placeholder="Enter your password"
                    name="password"
                    value={password}
                    onChange={onInputChange}
                    required
                  />
                </div>

                <div className="form-group">
                  <input
                    type="text"
                    className="form-control form-control-lg"
                    placeholder="Enter your phoneNumber"
                    name="phoneNumber"
                    value={phoneNumber}
                    onChange={onInputChange}
                    required
                  />
                </div>

                <div className="form-group">
                  <input
                    type="email"
                    className="form-control form-control-lg"
                    placeholder="Enter your emailID"
                    name="emailID"
                    value={emailID}
                    onChange={onInputChange}
                    required
                  />
                </div>

                <button type="submit" className="btn btn-danger btn-block">
                  Register
                </button>
              </form>
        </div>
      </div>
    </div>
  );
};

export default AddUser;
