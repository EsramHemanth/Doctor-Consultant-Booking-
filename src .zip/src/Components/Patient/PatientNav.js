import React from 'react'

const PatientNav = () => {
  return (
    <div>PatientNav</div>
  )
}

export default PatientNav