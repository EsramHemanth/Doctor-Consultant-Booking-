import React from 'react'

const PatientDashboard = () => {
  return (
    <div>PatientDashboard</div>
  )
}

export default PatientDashboard