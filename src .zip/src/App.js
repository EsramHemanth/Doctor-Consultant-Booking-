import logo from "./logo.svg";
import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Login from "./Components/Login";
import AdminDashboard from "./Components/Admin/AdminDashboard";
import AdminNav from "./Components/Admin/AdminNav";
import AdminUsers from "./Components/Admin/AdminUsers";
import AddUser from "./Components/Admin/AddUser";
import UserDetails from "./Components/Admin/UserDetails";
import EditUser from "./Components/Admin/EditUser";


import PatientDashboard from "./Components/Patient/PatientDashboard";
import PatientNav from "./Components/Patient/PatientNav";
import DoctorDashboard from "./Components/Doctor/DoctorDashBoard";
import DoctorNav from "./Components/Doctor/DoctorNav";
import AddDoctorDetails from "./Components/Doctor/AddDoctorDetails";


function App() {
  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/admin/admindashboard" element={<><AdminNav /><AdminDashboard /></>}/>
          <Route path="/admin/adminusers" element={<><AdminNav /><AdminUsers /></>}/>
          <Route path="/admin/adduser" element={<><AdminNav /><AddUser /></>}/>
          <Route path="/admin/userdetails/:id" element={<><AdminNav /><UserDetails /></>}/>
          <Route path="/admin/edituser/:id" element={<><AdminNav /><EditUser /></>}/>
          <Route path="/doctor/doctordashboard" element={<><DoctorNav /><DoctorDashboard /></>}/>
          <Route path="/doctor/adddoctordetails" element={<><DoctorNav /><AddDoctorDetails /></>}/>

          {/* <Route path='*' element={<PageNotFound/>}/> */}
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
